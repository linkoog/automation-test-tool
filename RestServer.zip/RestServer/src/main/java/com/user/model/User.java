package com.user.model;

import java.io.Serializable;

public class User implements Serializable
{
    private static final long serialVersionUID = 677484458789332877L;

    private Integer userId;

    private String userName;

    private String phoneNumber;
    
    private String email;

    private String address;

    /** 
    * @return userId 
    */
    public Integer getUserId()
    {
        return userId;
    }

    /**
     * @param userId the userId to set
     */
    public void setUserId(Integer userId)
    {
        this.userId = userId;
    }

    /** 
    * @return userName 
    */
    public String getUserName()
    {
        return userName;
    }

    /**
     * @param userName the userName to set
     */
    public void setUserName(String userName)
    {
        this.userName = userName;
    }

    /** 
    * @return email 
    */
    public String getEmail()
    {
        return email;
    }

    /**
     * @param email the email to set
     */
    public void setEmail(String email)
    {
        this.email = email;
    }

    /** 
    * @return address 
    */
    public String getAddress()
    {
        return address;
    }

    /**
     * @param address the address to set
     */
    public void setAddress(String address)
    {
        this.address = address;
    }

    /** 
    * @return phoneNumber 
    */
    public String getPhoneNumber()
    {
        return phoneNumber;
    }

    /**
     * @param phoneNumber the phoneNumber to set
     */
    public void setPhoneNumber(String phoneNumber)
    {
        this.phoneNumber = phoneNumber;
    }

    public void update(User usr)
    {
        if (null != usr.getUserId())
        {
            this.setUserId(usr.getUserId());
        }

        if (null != usr.getUserName())
        {
            this.setUserName(usr.getUserName());
        }

        if (null != usr.getEmail())
        {
            this.setEmail(usr.getEmail());
        }

        if (null != usr.getAddress())
        {
            this.setAddress(usr.getAddress());
        }

        if (null != usr.getPhoneNumber())
        {
            this.setPhoneNumber(usr.getPhoneNumber());
        }
    }
    
    /** (非 Javadoc) 
    * <p>Title: toString</p> 
    * <p>Description: </p> 
    * @return 
    * @see java.lang.Object#toString() 
    */
    @Override
    public String toString()
    {
        StringBuilder builder = new StringBuilder();
        builder.append("User [userId=");
        builder.append(userId);
        builder.append(", userName=");
        builder.append(userName);
        builder.append(", phoneNumber=");
        builder.append(phoneNumber);
        builder.append(", email=");
        builder.append(email);
        builder.append(", address=");
        builder.append(address);
        builder.append("]");
        return builder.toString();
    }

}
