package com.user.service.impl;

import java.util.HashMap;
import java.util.Map;

import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.user.model.User;
import com.user.service.IUserService;

@Produces({ MediaType.APPLICATION_JSON})
public class UserServiceImpl implements IUserService
{
    private Map<Integer, User> users = new HashMap<Integer, User>();

    public User addUser(User user)
    {
        Integer userId = 1;
        
        user.setUserId(userId);
        users.put(userId, user);
        
        return user;
    }
    
    public void deleteUser(Integer userId)
    {
        users.remove(userId);
    }

    public User getUser(Integer userId)
    {
        return users.get(userId);
    }

    public void updateUser(User user)
    {
        User usr = users.get(user.getUserId());
        if (null == usr)
        {
            return;
        }
        usr.update(user);
    }

}
