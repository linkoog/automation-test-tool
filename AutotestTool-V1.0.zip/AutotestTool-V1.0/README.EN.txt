﻿Autotest is an automated testing tool developed by individual.

This tool supports automated testing RESTful API, produced beautiful report. 

The author is now coding for a living. 

If you want to get the full source code, please contact the author by e-mail.

Thank you for your support for the Autotest!

*****************************************
Author:  Dom Wang
Email:   witpool@outlook.com
*****************************************
